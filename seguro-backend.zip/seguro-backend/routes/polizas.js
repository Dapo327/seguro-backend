const express = require('express');
const router = express.Router();
const Poliza = require('../models/Poliza');

// Crear una póliza
router.post('/', async (req, res) => {
  try {
    const poliza = new Poliza(req.body);
    await poliza.save();
    res.status(201).send(poliza);
  } catch (error) {
    res.status(400).send(error);
  }
});

// Obtener todas las pólizas
router.get('/', async (req, res) => {
  try {
    const polizas = await Poliza.find();
    res.send(polizas);
  } catch (error) {
    res.status(500).send(error);
  }
});

// Obtener una póliza por número de póliza
router.get('/:numeroPoliza', async (req, res) => {
  try {
    const poliza = await Poliza.findOne({ numeroPoliza: req.params.numeroPoliza });
    if (!poliza) {
      return res.status(404).send();
    }
    res.send(poliza);
  } catch (error) {
    res.status(500).send(error);
  }
});

// Actualizar una póliza
router.put('/:numeroPoliza', async (req, res) => {
  try {
    const poliza = await Poliza.findOneAndUpdate({ numeroPoliza: req.params.numeroPoliza }, req.body, { new: true });
    if (!poliza) {
      return res.status(404).send();
    }
    res.send(poliza);
  } catch (error) {
    res.status(400).send(error);
  }
});

// Eliminar una póliza
router.delete('/:numeroPoliza', async (req, res) => {
  try {
    const poliza = await Poliza.findOneAndDelete({ numeroPoliza: req.params.numeroPoliza });
    if (!poliza) {
      return res.status(404).send();
    }
    res.send(poliza);
  } catch (error) {
    res.status(500).send(error);
  }
});

module.exports = router;